# encoding: utf-8

from .triplet_sampler import RandomIdentitySampler, RandomIdentitySampler_alignedreid   
