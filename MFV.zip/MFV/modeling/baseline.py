# encoding: utf-8
import math
import torch  
from torch import nn
from modeling.backbones.resnet import ResNet, BasicBlock, Bottleneck
from modeling.backbones.senet import SENet, SEResNetBottleneck, SEBottleneck, SEResNeXtBottleneck
from modeling.backbones.resnet_ibn_a import resnet50_ibn_a
from modeling.Transformer import Transformer
import torch.nn.functional as F

def weights_init_kaiming(m):
    classname = m.__class__.__name__
    if classname.find('Linear') != -1:
        nn.init.kaiming_normal_(m.weight, a=0, mode='fan_out')
        nn.init.constant_(m.bias, 0.0)
    elif classname.find('Conv') != -1:
        nn.init.kaiming_normal_(m.weight, a=0, mode='fan_in')
        if m.bias is not None:
            nn.init.constant_(m.bias, 0.0)
    elif classname.find('BatchNorm') != -1:
        if m.affine:
            nn.init.constant_(m.weight, 1.0)
            nn.init.constant_(m.bias, 0.0)

def weights_init_classifier(m):
    classname = m.__class__.__name__
    if classname.find('Linear') != -1:
        nn.init.normal_(m.weight, std=0.001)
        if m.bias:
            nn.init.constant_(m.bias, 0.0)

class ClassBlock(nn.Module):
    def __init__(self, input_dim, class_num):
        super(ClassBlock, self).__init__()

        add_block = []
        add_block =add_block + [nn.Conv2d(input_dim, input_dim//4, kernel_size=1)]
        add_block =add_block + [nn.BatchNorm2d(input_dim//4)]
        add_block =add_block + [nn.Conv2d(input_dim//4, input_dim//16, kernel_size=1)]
        add_block =add_block + [nn.BatchNorm2d(input_dim//16)]
        add_block =add_block + nn.Sequential(*add_block)

        classifier = []
        classifier = classifier + [nn.Linear(input_dim//16, 2)]
        classifier = nn.Sequential(*classifier)

        self.add_block = add_block
        self.classifier = classifier
        self.gap = nn.AdaptiveAvgPool2d(1)


    def forward(self, x):
        x = self.add_block(x)
        x = self.gap(x).squeeze()
        x = self.classifier(x)

        return x

def _make_layer(block, inplanes, planes, blocks, stride=2):
    downsample = None
    if stride != 1 or inplanes != planes * block.expansion:
        downsample = nn.Sequential(
            nn.Conv2d(inplanes, planes * block.expansion,kernel_size=1, stride=stride, bias=False),
            nn.BatchNorm2d(planes * block.expansion),
        )

    layers = []
    layers.append(block(inplanes, planes, stride, downsample))
    inplanes = planes * block.expansion
    for i in range(1, blocks):
        layers.append(block(inplanes, planes))

    return nn.Sequential(*layers)

class Baseline(nn.Module):
    in_planes = 2048

    def __init__(self, num_classes, last_stride, model_path, neck, neck_feat, model_name, pretrain_choice, bot_depth, tfc_depth, in_dim):
        super(Baseline, self).__init__()
        if model_name == 'resnet18':
            self.in_planes = 512
            self.base = ResNet(last_stride=last_stride, 
                               block=BasicBlock, 
                               layers=[2, 2, 2, 2])
        elif model_name == 'resnet34':
            self.in_planes = 512
            self.base = ResNet(last_stride=last_stride,
                               block=BasicBlock,
                               layers=[3, 4, 6, 3])
        elif model_name == 'resnet50':
            self.base = ResNet(last_stride=last_stride,
                               block=Bottleneck,
                               layers=[3, 4, 6, 3])
        elif model_name == 'resnet101':
            self.base = ResNet(last_stride=last_stride,
                               block=Bottleneck, 
                               layers=[3, 4, 23, 3])
        elif model_name == 'resnet152':
            self.base = ResNet(last_stride=last_stride, 
                               block=Bottleneck,
                               layers=[3, 8, 36, 3])
            
        elif model_name == 'se_resnet50':
            self.base = SENet(block=SEResNetBottleneck, 
                              layers=[3, 4, 6, 3], 
                              groups=1, 
                              reduction=16,
                              dropout_p=None, 
                              inplanes=64, 
                              input_3x3=False,
                              downsample_kernel_size=1, 
                              downsample_padding=0,
                              last_stride=last_stride) 
        elif model_name == 'se_resnet101':
            self.base = SENet(block=SEResNetBottleneck, 
                              layers=[3, 4, 23, 3], 
                              groups=1, 
                              reduction=16,
                              dropout_p=None, 
                              inplanes=64, 
                              input_3x3=False,
                              downsample_kernel_size=1, 
                              downsample_padding=0,
                              last_stride=last_stride)
        elif model_name == 'se_resnet152':
            self.base = SENet(block=SEResNetBottleneck, 
                              layers=[3, 8, 36, 3],
                              groups=1, 
                              reduction=16,
                              dropout_p=None, 
                              inplanes=64, 
                              input_3x3=False,
                              downsample_kernel_size=1, 
                              downsample_padding=0,
                              last_stride=last_stride)  
        elif model_name == 'se_resnext50':
            self.base = SENet(block=SEResNeXtBottleneck,
                              layers=[3, 4, 6, 3], 
                              groups=32, 
                              reduction=16,
                              dropout_p=None, 
                              inplanes=64, 
                              input_3x3=False,
                              downsample_kernel_size=1, 
                              downsample_padding=0,
                              last_stride=last_stride) 
        elif model_name == 'se_resnext101':
            self.base = SENet(block=SEResNeXtBottleneck,
                              layers=[3, 4, 23, 3], 
                              groups=32, 
                              reduction=16,
                              dropout_p=None, 
                              inplanes=64, 
                              input_3x3=False,
                              downsample_kernel_size=1, 
                              downsample_padding=0,
                              last_stride=last_stride)
        elif model_name == 'senet154':
            self.base = SENet(block=SEBottleneck, 
                              layers=[3, 8, 36, 3],
                              groups=64, 
                              reduction=16,
                              dropout_p=0.2, 
                              last_stride=last_stride)
        elif model_name == 'resnet50_ibn_a':
            self.base = resnet50_ibn_a(last_stride)

        if pretrain_choice == 'imagenet':
            self.base.load_param(model_path)
            print('Loading pretrained ImageNet model......')

        self.gap1 = nn.AdaptiveAvgPool2d(1)
        self.gap2 = nn.AdaptiveAvgPool2d(1)
        self.gap3 = nn.AdaptiveAvgPool2d(1)
        self.num_classes = num_classes
        self.neck = neck
        self.neck_feat = neck_feat

        self.HAT = HAT(
            img_size=(16, 8),
            patch_size=1,
            in_dim=in_dim,
            poi_dim=2048,
            tfc_depth=tfc_depth,
            heads=16,
            mlp_dim=2048,
            dropout=0.1,
            emb_dropout=0.1,
            )

        self.backbone_planes = 2048
        f_dim1, f_dim2, f_dim3 = in_dim

        self.bottleneck_b = nn.BatchNorm1d(self.backbone_planes)
        self.bottleneck_b.bias.requires_grad_(False)
        self.classifier_b = nn.Linear(self.backbone_planes, self.num_classes, bias=False)
        self.bottleneck_t1 = nn.BatchNorm1d(2048)
        self.bottleneck_t1.bias.requires_grad_(False)
        self.classifier_t1 = nn.Linear(2048, self.num_classes, bias=False)
        self.bottleneck_t2 = nn.BatchNorm1d(2048)
        self.bottleneck_t2.bias.requires_grad_(False)
        self.classifier_t2 = nn.Linear(256, self.num_classes, bias=False)
        self.bottleneck_t3 = nn.BatchNorm1d(self.backbone_planes)
        self.bottleneck_t3.bias.requires_grad_(False)
        self.classifier_t3 = nn.Linear(256, self.num_classes, bias=False)
        self.bottleneck_b.apply(weights_init_kaiming)
        self.classifier_b.apply(weights_init_classifier)
        self.bottleneck_t1.apply(weights_init_kaiming)
        self.classifier_t1.apply(weights_init_classifier)
        self.bottleneck_t2.apply(weights_init_kaiming)
        self.classifier_t2.apply(weights_init_classifier)
        self.bottleneck_t3.apply(weights_init_kaiming)
        self.classifier_t3.apply(weights_init_classifier)
        self.non_linear1 = _make_layer(Bottleneck, f_dim1, f_dim1//4, bot_depth, stride=1)
        self.non_linear2 = _make_layer(Bottleneck, f_dim2, f_dim2//4, bot_depth, stride=1)
        self.non_linear3 = _make_layer(Bottleneck, f_dim3, f_dim3//4, bot_depth, stride=1)
        self.max_pool1 = nn.AdaptiveMaxPool2d((16, 8))
        self.max_pool2 = nn.AdaptiveMaxPool2d((16, 8))

    def forward(self, x):

        x = self.base.conv1(x)
        x = self.base.bn1(x)
        x = self.base.maxpool(x)
        x1 = self.base.layer1(x)
        x2 = self.base.layer2(x1)
        x3 = self.base.layer3(x2)
        x = self.base.layer4(x3)

        gap_b = self.gap1(x).squeeze()

        x_t_1 = self.max_pool1(self.non_linear1(x1))
        x_t_2 = self.max_pool2(self.non_linear2(x2))
        x_t_3 = self.non_linear3(x3)

        x_mid_1, x_mid_2, x_mid_3 = self.HAT(x_t_1, x_t_2, x_t_3)
        feat_t1 = x_mid_1[:, ::4, ::2, ::2].reshape(64, 2048)
        feat_t2 = x_mid_2[:, ::4, ::2, ::2].reshape(64, 2048)
        feat_t3 = x_mid_3[:, ::4, ::2, ::2].reshape(64, 2048)
        feat_b = self.bottleneck_b(gap_b)
        feat_t1 = self.bottleneck_t1(feat_t1)
        feat_t2 = self.bottleneck_t2(feat_t2)
        feat_t3 = self.bottleneck_t3(feat_t3)

        if self.training:
            cls_score_b = self.classifier_b(feat_b)
            cls_score_t1 = self.classifier_t1(feat_t1)
            cls_score_t2 = self.classifier_t1(feat_t2)
            cls_score_t3 = self.classifier_t1(feat_t3)

            return [cls_score_b, cls_score_t3, cls_score_t1, cls_score_t2], [gap_b, x_mid_3, x_mid_1, x_mid_2]
        else:
            return torch.cat((feat_b, feat_t3), dim=1)

    def load_param(self, trained_path):
        param_dict = torch.load(trained_path)
        for k,v in param_dict.state_dict().items():
            if 'classifier' in k:
                continue
            self.state_dict()[k].copy_(param_dict.state_dict()[k])

class TFE(nn.Module):
    def __init__(self, in_channel, out_channel, img_size, num_patch, p_size, emb_dropout, T_depth, heads, dim_head, mlp_dim, dropout = 0.1):
        super(TFE, self).__init__()

        height, width = img_size

        self.p_size = p_size

        self.patch_to_embedding = nn.Linear(in_channel, out_channel)
        self.cls_token = nn.Parameter(torch.randn(1, 1, out_channel))
        self.pos_embedding = nn.Parameter(torch.randn(1, num_patch + 1, out_channel))
        self.dropout = nn.Dropout(emb_dropout)
        self.transformer = Transformer(out_channel, T_depth, heads, dim_head, mlp_dim, dropout,in_channel,kernel_att=7, kernel_conv=3, stride=1, dilation=1)
        self.to_latent = nn.Identity()
        self.NeA = Bottleneck(out_channel, out_channel//4)
        self.Softmax = nn.Softmax()
        self.conv1 = nn.Conv2d(in_channel, out_channel, kernel_size=3, stride=1, padding=1, bias=False)
        self.conv2 = nn.Conv2d(in_channel, out_channel, kernel_size=5, stride=1, padding=2, bias=False)
        self.bn2 = nn.BatchNorm2d(in_channel)
        self.relu = nn.ReLU(inplace=False)
        self.sigmoid = nn.Sigmoid()
        self.maxpool1 = nn.MaxPool2d(kernel_size=3, stride=1, padding=1)

        self.conv1 = nn.Conv2d(256, 256, kernel_size=1, bias=False)
        self.bn1 = nn.BatchNorm2d(256)

        self.conv2 = nn.Conv2d(256, 256, kernel_size=3, stride=1, padding=1, bias=False)
        self.bn2 = nn.BatchNorm2d(256)

        self.conv3 = nn.Conv2d(256,256 * 4, kernel_size=1, bias=False)
        self.bn3 = nn.BatchNorm2d(256 * 4)
        self.maxpool1 = nn.MaxPool2d(kernel_size=1, stride=1, padding=0)
        self.maxpool2 = nn.MaxPool2d(kernel_size=2, stride=2, ceil_mode=True)
        self.Bottle2neck = Bottle2neck(256,256//4)
    def forward(self, x, mask=None):

        if x.shape == (64, 8, 16, 256):
           x = x.reshape(64, 256, 16, 8)
        if x.shape == (64, 32, 64, 64):
           x = x.reshape(64, 64, 64, 32)

        if x.shape == (64, 8, 16, 256):
            x = x.permute(0, 3, 2, 1)
        if x.shape == (64, 3, 256, 128):
            x = x.permute(0, 2, 1, 3)
            x = x[:,:,::3,:]

        x = self.conv1(x)
        x = self.bn1(x)
        x = self.relu(x)
        x = self.maxpool1(x)

        x = self.conv2(x)
        x = self.bn2(x)
        x = self.relu(x)
        x = self.maxpool1(x)

        x = self.conv3(x)
        x = self.bn3(x)
        x = self.relu(x)
        x = self.maxpool1(x)[:, ::4, :, :]

        x = self.transformer(x)

        if x.shape == (64, 256, 16, 8):
            x = x.reshape(64, 8, 16, 256)

        x = x.permute(0, 3, 2, 1)
        x_mid = x
        x_mid = self.to_latent(x_mid)
        x = x.reshape(64, 8, 16, 256)
        return x, x_mid

class Bottle2neck(nn.Module):
    expansion = 4

    def __init__(self, inplanes, planes, stride=1, downsample=None, baseWidth=26, scale = 4, stype='normal'):
        """ Constructor
        Args:
            inplanes: input channel dimensionality
            planes: output channel dimensionality
            stride: conv stride. Replaces pooling layer.
            downsample: None when stride = 1
            baseWidth: basic width of conv3x3
            scale: number of scale.
            type: 'normal': normal set. 'stage': first block of a new stage.
        """
        super(Bottle2neck, self).__init__()
        width = int(math.floor(planes * (baseWidth/64.0)))
        self.conv1 = nn.Conv2d(inplanes, width*scale, kernel_size=1, bias=False)
        self.bn1 = nn.BatchNorm2d(width*scale)

        if scale == 1:
            self.nums = 1
        else:
            self.nums = scale - 1
        if stype == 'stage':
            self.pool = nn.AvgPool2d(kernel_size=3, stride = stride, padding=1)
        convs = []
        bns = []
        for i in range(self.nums):
            convs.append(nn.Conv2d(width, width, kernel_size=3, stride = stride, padding=1, bias=False))
            bns.append(nn.BatchNorm2d(width))
        self.convs = nn.ModuleList(convs)
        self.bns = nn.ModuleList(bns)

        self.conv3 = nn.Conv2d(width*scale, planes * self.expansion, kernel_size=1, bias=False)
        self.bn3 = nn.BatchNorm2d(planes * self.expansion)

        self.relu = nn.ReLU(inplace=True)
        self.downsample = downsample
        self.stype = stype
        self.scale = scale
        self.width  = width

    def forward(self, x):
        if x.shape == (64, 8, 16, 256):
            x = x.reshape(64, 256, 16, 8)

        residual = x
        out = self.conv1(x)
        out = self.bn1(out)
        out = self.relu(out)

        spx = torch.split(out, self.width, 1)
        for i in range(self.nums):
            if i==0 or self.stype=='stage':
                sp = spx[i]
            else:
                sp = sp + spx[i]
            sp = self.convs[i](sp)
            sp = self.relu(self.bns[i](sp))
            if i==0:
                out = sp
            else:
                out = torch.cat((out, sp), 1)

        if self.scale != 1 and self.stype=='normal':
            out = torch.cat((out, spx[self.nums]),1)
        elif self.scale != 1 and self.stype=='stage':
            out = torch.cat((out, self.pool(spx[self.nums])),1)

        out = self.conv3(out)
        out = self.bn3(out)

        if self.downsample is not None:
            residual = self.downsample(x)
        out += residual
        out = self.relu(out)
        if out.shape == (64, 256, 16, 8):
            out = out.reshape(64, 8, 16, 256)
        return out


class MFV(nn.Module):
    def __init__(self, img_size, patch_size, in_dim, poi_dim, heads, mlp_dim, tfe_depth, dim_head=64, dropout=0.1, emb_dropout=0.1):
        super(MFV, self).__init__()
        T_depth1, T_depth2, T_depth3 = tfe_depth
        inc1, inc2, inc3 = in_dim
        self.TFE_S1 = TFE(in_channel=inc1, out_channel=inc1, img_size=[16, 8], num_patch=128, p_size=1, emb_dropout=0.1, T_depth=T_depth1,
                          heads=heads, dim_head=dim_head, mlp_dim=mlp_dim, dropout=0.1)
        self.TFE_S2 = TFE(in_channel=inc1, out_channel=inc1, img_size=[16, 8], num_patch=128, p_size=1, emb_dropout=0.1, T_depth=T_depth2,
                          heads=heads, dim_head=dim_head, mlp_dim=mlp_dim, dropout=0.1)
        self.TFE_S3 = TFE(in_channel=inc1, out_channel=256, img_size=[16, 8], num_patch=128, p_size=1, emb_dropout=0.1, T_depth=T_depth3,
                          heads=heads, dim_head=dim_head, mlp_dim=mlp_dim, dropout=0.1)
    def forward(self, x1, x2, x3, mask=None):
        x1, x_mid_1 = self.TFE_S1(x1)
        x2 = x2[:, ::2, :, :]
        x2 = x2.reshape(64, 8, 16, 256)
        x2, x_mid_2 = self.TFE_S2(torch.cat((x2, x1), dim=1)[:, ::2, :, :])
        x3 = x3[:, ::4, :, :]
        x3 = x3.reshape(64, 8, 16, 256)
        x3, x_mid_3 = self.TFE_S3(torch.cat((x3, x2), dim=1)[:, ::2, :, :])

        return x_mid_1, x_mid_2, x_mid_3
